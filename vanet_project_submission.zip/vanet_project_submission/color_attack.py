import os
import sys
import time

if "SUMO_HOME" in os.environ:
    tools = os.path.join(os.environ["SUMO_HOME"], "tools")
    sys.path.append(tools)
else:
    sys.exit("Please declare environment variable 'SUMO_HOME'")

import traci

SUMO_CONFIG = "/home/adnan/vanet/sim.sumocfg"
ATTACK_FILE = "/home/adnan/vanet/attack_visual.txt"

ATTACKER_COLOR = (255, 0, 0, 255)      # red
SPOOFED_COLOR = (255, 165, 0, 255)     # orange
VICTIM_COLOR = (255, 255, 0, 255)      # yellow
BLOCKED_COLOR = (128, 0, 128, 255)     # purple

def load_events(filepath):
    events = {}
    if not os.path.exists(filepath):
        print("attack_visual.txt not found")
        return events

    with open(filepath, "r") as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) != 3:
                continue

            step = int(parts[0])
            veh_id = parts[1]
            role = parts[2]

            if step not in events:
                events[step] = []

            events[step].append((veh_id, role))

    return events

def apply_color(veh_id, role):
    veh_name = str(veh_id)

    if veh_name not in traci.vehicle.getIDList():
        return False

    if role == "attacker":
        traci.vehicle.setColor(veh_name, ATTACKER_COLOR)
    elif role == "spoofed":
        traci.vehicle.setColor(veh_name, SPOOFED_COLOR)
    elif role == "victim":
        traci.vehicle.setColor(veh_name, VICTIM_COLOR)
    elif role == "blocked":
        traci.vehicle.setColor(veh_name, BLOCKED_COLOR)

    traci.vehicle.setWidth(veh_name, 3.5)
    traci.vehicle.setLength(veh_name, 8.0)
    return True

def show_accident_marker(veh_id):
    veh_name = str(veh_id)

    if veh_name not in traci.vehicle.getIDList():
        return False

    x, y = traci.vehicle.getPosition(veh_name)
    poi_id = f"accident_{veh_name}"

    if poi_id not in traci.poi.getIDList():
        traci.poi.add(poi_id, x, y, (255, 0, 0, 255), "ACCIDENT")

    return True

def highlight_accident_scene(attacker_id, victim_id=None):
    attacker = str(attacker_id)

    if attacker in traci.vehicle.getIDList():
        traci.vehicle.setColor(attacker, ATTACKER_COLOR)
        traci.vehicle.setWidth(attacker, 5.0)
        traci.vehicle.setLength(attacker, 12.0)

        try:
            traci.vehicle.slowDown(attacker, 0.1, 5.0)
        except:
            pass

        traci.gui.trackVehicle("View #0", attacker)
        traci.gui.setZoom("View #0", 1600)

    if victim_id is not None:
        victim = str(victim_id)
        if victim in traci.vehicle.getIDList():
            traci.vehicle.setColor(victim, VICTIM_COLOR)
            traci.vehicle.setWidth(victim, 5.0)
            traci.vehicle.setLength(victim, 12.0)

            try:
                traci.vehicle.slowDown(victim, 0.1, 5.0)
            except:
                pass

def main():
    events = load_events(ATTACK_FILE)

    traci.start(["sumo-gui", "-c", SUMO_CONFIG, "--start"])

    step = 0
    max_steps = 400
    active_roles = {}
    last_victim = None

    while step < max_steps and traci.simulation.getMinExpectedNumber() > 0:
        traci.simulationStep()
        time.sleep(0.4)

        if step in events:
            print(f"Step {step}:")
            current_attacker = None
            current_victim = None

            for veh_id, role in events[step]:
                print(f"  {veh_id} -> {role}")

                if role == "victim":
                    current_victim = veh_id
                    last_victim = veh_id
                    active_roles[veh_id] = role

                elif role == "attacker":
                    current_attacker = veh_id
                    active_roles[veh_id] = role

                elif role == "accident":
                    show_accident_marker(veh_id)

                else:
                    active_roles[veh_id] = role

            if current_attacker is not None:
                highlight_accident_scene(current_attacker, current_victim or last_victim)

        for veh_id, role in active_roles.items():
            apply_color(veh_id, role)

        step += 1

    input("Press Enter to close SUMO...")
    traci.close()

if __name__ == "__main__":
    main()
