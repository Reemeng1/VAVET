#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/mobility-module.h"
#include "ns3/internet-module.h"
#include "ns3/wifi-module.h"
#include "ns3/yans-wifi-helper.h"
#include "ns3/aodv-module.h"

#include <fstream>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("VanetSpoofing");

int sentPackets = 0;
int receivedPackets = 0;
int totalBytes = 0;

int beaconMessages = 0;
int safetyMessages = 0;
int trafficMessages = 0;

int normalMessages = 0;
int spoofedMessagesSent = 0;
int spoofedMessagesDetected = 0;
int blockedSpoofedMessages = 0;

std::ofstream visualFile;

std::string detectionField = "sender vs claimedId";
int attackerVehicle = 19;
int spoofedIdentity = 0;
int victimVehicle = 2;

static void
ReceivePacket(Ptr<Socket> socket)
{
    Ptr<Packet> packet;
    Address from;

    while ((packet = socket->RecvFrom(from)))
    {
        receivedPackets++;
        totalBytes += packet->GetSize();

        uint8_t *buffer = new uint8_t[packet->GetSize() + 1];
        packet->CopyData(buffer, packet->GetSize());
        buffer[packet->GetSize()] = '\0';

        std::string msg = std::string(reinterpret_cast<char *>(buffer));
        delete[] buffer;

        std::cout << "\n[APP PACKET]" << std::endl;
        std::cout << "Time: " << Simulator::Now().GetSeconds() << " s" << std::endl;
        std::cout << "Payload: " << msg << std::endl;

        if (msg.find("msgType=SAFETY_ALERT") != std::string::npos)
        {
            safetyMessages++;
            std::cout << "[SECURITY CLASS] High-priority safety message" << std::endl;
        }
        else if (msg.find("msgType=SPEED_REPORT") != std::string::npos ||
                 msg.find("msgType=TRAFFIC_STATUS") != std::string::npos)
        {
            trafficMessages++;
            std::cout << "[SECURITY CLASS] Traffic information message" << std::endl;
        }
        else if (msg.find("msgType=BEACON") != std::string::npos)
        {
            beaconMessages++;
            std::cout << "[SECURITY CLASS] Periodic beacon message" << std::endl;
        }

        size_t senderPos = msg.find("sender=vehicle");
        size_t claimedPos = msg.find("claimedId=");

        if (senderPos != std::string::npos && claimedPos != std::string::npos)
        {
            size_t senderStart = senderPos + std::string("sender=vehicle").length();
            size_t senderEnd = msg.find(";", senderStart);
            if (senderEnd == std::string::npos)
            {
                senderEnd = msg.length();
            }
            std::string senderId = msg.substr(senderStart, senderEnd - senderStart);

            size_t claimedStart = claimedPos + std::string("claimedId=").length();
            size_t claimedEnd = msg.find(";", claimedStart);
            if (claimedEnd == std::string::npos)
            {
                claimedEnd = msg.length();
            }
            std::string claimedId = msg.substr(claimedStart, claimedEnd - claimedStart);

            if (senderId != claimedId)
            {
                spoofedMessagesDetected++;
                blockedSpoofedMessages++;

                std::cout << "[DETECTION] " << Simulator::Now().GetSeconds()
                          << "s -> spoofing detected: sender=vehicle" << senderId
                          << " but claimedId=" << claimedId << std::endl;

                std::cout << "[DETECTION FIELD] detection based on mismatch between sender and claimedId"
                          << std::endl;

                std::cout << "[AI DECISION] message classified as malicious" << std::endl;
                std::cout << "[PREVENTION] spoofed packet dropped" << std::endl;
                std::cout << "[PREVENTION] attacker vehicle" << senderId
                          << " marked as suspicious" << std::endl;
                return;
            }
            else
            {
                normalMessages++;
                std::cout << "[DETECTION] " << Simulator::Now().GetSeconds()
                          << "s -> no spoofing: sender matches claimedId" << std::endl;
            }
        }
    }
}

static void
SendMessage(Ptr<Socket> socket, std::string message)
{
    Ptr<Packet> packet = Create<Packet>(
        reinterpret_cast<const uint8_t *>(message.c_str()),
        message.size());

    socket->Send(packet);
}

static void
SendPeriodicMessage(Ptr<Socket> socket, std::string message, double interval, double stopTime)
{
    if (Simulator::Now().GetSeconds() >= stopTime)
    {
        return;
    }

    Ptr<Packet> packet = Create<Packet>(
        reinterpret_cast<const uint8_t *>(message.c_str()),
        message.size());

    socket->Send(packet);
    sentPackets++;

    Simulator::Schedule(Seconds(interval), &SendPeriodicMessage, socket, message, interval, stopTime);
}

static void
PrintAttackStep(std::string msg)
{
    std::cout << "[ATTACK STEP] " << Simulator::Now().GetSeconds()
              << "s -> " << msg << std::endl;
}

int
main(int argc, char *argv[])
{
    std::srand(std::time(nullptr));

    visualFile.open("/home/adnan/vanet/attack_visual.txt");
    if (!visualFile.is_open())
    {
        std::cerr << "Could not open attack_visual.txt" << std::endl;
        return 1;
    }

    uint32_t numVehicles = 40;
    uint32_t numRsu = 2;
    double simTime = 40.0;
spoofedIdentity = 1 + std::rand() % 15;
while (spoofedIdentity == attackerVehicle)
{
    spoofedIdentity = 1 + std::rand() % 15;
}

victimVehicle = 1 + std::rand() % 15;
while (victimVehicle == attackerVehicle || victimVehicle == spoofedIdentity)
{
    victimVehicle = 1 + std::rand() % 15;
}
double attackTime1 = 15.0;
double attackTime2 = 18.0;
double attackTime3 = 22.0;
double attackTime4 = 26.0;

    visualFile << (int)attackTime1 << " " << attackerVehicle << " attacker\n";
    visualFile << (int)attackTime1 << " " << spoofedIdentity << " spoofed\n";
    visualFile << (int)attackTime1 << " " << victimVehicle << " victim\n";
visualFile << (int)attackTime1 << " " << attackerVehicle << " accident\n";
    visualFile << (int)attackTime2 << " " << attackerVehicle << " attacker\n";
    visualFile << (int)attackTime2 << " " << spoofedIdentity << " spoofed\n";

    visualFile << (int)attackTime3 << " " << attackerVehicle << " attacker\n";
    visualFile << (int)attackTime3 << " " << victimVehicle << " victim\n";

    visualFile << (int)attackTime4 << " " << attackerVehicle << " blocked\n";

    std::cout << "===== RANDOM SCENARIO SETTINGS =====" << std::endl;
    std::cout << "Attacker Vehicle: " << attackerVehicle << std::endl;
    std::cout << "Spoofed Identity: " << spoofedIdentity << std::endl;
    std::cout << "Victim Vehicle: " << victimVehicle << std::endl;
    std::cout << "Attack Time 1: " << attackTime1 << " s" << std::endl;
    std::cout << "Attack Time 2: " << attackTime2 << " s" << std::endl;
    std::cout << "Attack Time 3: " << attackTime3 << " s" << std::endl;
    std::cout << "Attack Time 4: " << attackTime4 << " s" << std::endl;

    NodeContainer vehicles;
    vehicles.Create(numVehicles);

    NodeContainer rsus;
    rsus.Create(numRsu);

    NodeContainer allNodes;
    allNodes.Add(vehicles);
    allNodes.Add(rsus);

    YansWifiChannelHelper channel = YansWifiChannelHelper::Default();
    YansWifiPhyHelper phy;
    phy.SetChannel(channel.Create());
    phy.Set("TxPowerStart", DoubleValue(33.0));
    phy.Set("TxPowerEnd", DoubleValue(33.0));

    WifiHelper wifi;
    wifi.SetStandard(WIFI_STANDARD_80211a);

    WifiMacHelper mac;
    mac.SetType("ns3::AdhocWifiMac");

    NetDeviceContainer devices = wifi.Install(phy, mac, allNodes);

    MobilityHelper mobility;
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    mobility.Install(vehicles);

    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    mobility.Install(rsus);

    rsus.Get(0)->GetObject<MobilityModel>()->SetPosition(Vector(50.0, 20.0, 0.0));
    rsus.Get(1)->GetObject<MobilityModel>()->SetPosition(Vector(140.0, 20.0, 0.0));

    std::ifstream file("/home/adnan/vanet/positions.txt");
    if (!file.is_open())
    {
        std::cerr << "Could not open /home/adnan/vanet/positions.txt" << std::endl;
        return 1;
    }

    int step, vehId;
    double x, y;

    while (file >> step >> vehId >> x >> y)
    {
        if (vehId >= 0 && vehId < (int)numVehicles)
        {
            Ptr<MobilityModel> mob = vehicles.Get(vehId)->GetObject<MobilityModel>();

            Simulator::Schedule(Seconds(step),
                                &MobilityModel::SetPosition,
                                mob,
                                Vector(x / 10.0, y / 10.0, 0.0));
        }
    }
    file.close();

    AodvHelper aodv;
    InternetStackHelper internet;
    internet.SetRoutingHelper(aodv);
    internet.Install(allNodes);

    Ipv4AddressHelper ipv4;
    ipv4.SetBase("10.1.1.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces = ipv4.Assign(devices);

    uint16_t spoofPort = 7000;

    Ptr<Socket> recvSocket = Socket::CreateSocket(vehicles.Get(1), UdpSocketFactory::GetTypeId());
    InetSocketAddress local = InetSocketAddress(Ipv4Address::GetAny(), spoofPort);
    recvSocket->Bind(local);
    recvSocket->SetRecvCallback(MakeCallback(&ReceivePacket));

    Ptr<Socket> normalSocket = Socket::CreateSocket(vehicles.Get(0), UdpSocketFactory::GetTypeId());
    InetSocketAddress remoteNormal = InetSocketAddress(interfaces.GetAddress(1), spoofPort);
    normalSocket->Connect(remoteNormal);

    Simulator::Schedule(Seconds(2.0), &PrintAttackStep,
                        std::string("normal communication: vehicle0 starts periodic beacon transmission"));

    Simulator::Schedule(Seconds(2.0), &SendPeriodicMessage,
                        normalSocket,
                        std::string("msgType=BEACON;sender=vehicle0;claimedId=0;speed=16;posX=45;posY=80;lane=A1;status=normal"),
                        1.0, 20.0);

    Ptr<Socket> normalSocket2 = Socket::CreateSocket(vehicles.Get(3), UdpSocketFactory::GetTypeId());
    normalSocket2->Connect(remoteNormal);

    Simulator::Schedule(Seconds(2.5), &SendPeriodicMessage,
                        normalSocket2,
                        std::string("msgType=BEACON;sender=vehicle3;claimedId=3;speed=14;posX=60;posY=90;lane=B1;status=normal"),
                        1.5, 22.0);

    Ptr<Socket> normalSocket3 = Socket::CreateSocket(vehicles.Get(5), UdpSocketFactory::GetTypeId());
    normalSocket3->Connect(remoteNormal);

    Simulator::Schedule(Seconds(3.0), &SendPeriodicMessage,
                        normalSocket3,
                        std::string("msgType=TRAFFIC_STATUS;sender=vehicle5;claimedId=5;speed=12;posX=75;posY=95;density=medium;status=normal"),
                        2.0, 24.0);

    Ptr<Socket> maliciousSocket = Socket::CreateSocket(vehicles.Get(attackerVehicle), UdpSocketFactory::GetTypeId());
    InetSocketAddress remoteAttack = InetSocketAddress(interfaces.GetAddress(victimVehicle), spoofPort);
    maliciousSocket->Connect(remoteAttack);

    Simulator::Schedule(Seconds(attackTime1), &PrintAttackStep,
                        std::string("attack starts: vehicle19 launches ID spoofing"));

    Simulator::Schedule(Seconds(attackTime1), &PrintAttackStep,
                        std::string("vehicle19 pretends to be vehicle" + std::to_string(spoofedIdentity)));

    Simulator::Schedule(Seconds(attackTime1), &PrintAttackStep,
                        std::string("a fake accident alert is injected into the network"));

    Simulator::Schedule(Seconds(attackTime1), &SendMessage,
                        maliciousSocket,
                        std::string("msgType=SAFETY_ALERT;sender=vehicle19;claimedId=" + std::to_string(spoofedIdentity) +
                                    ";speed=18;posX=102;posY=55;event=accident_warning;priority=high;attack=spoofing"));
    sentPackets++;
    spoofedMessagesSent++;

    Simulator::Schedule(Seconds(attackTime1 + 2.0), &SendMessage,
                        maliciousSocket,
                        std::string("msgType=SAFETY_ALERT;sender=vehicle19;claimedId=" + std::to_string(spoofedIdentity) +
                                    ";speed=18;posX=104;posY=58;event=accident_warning;priority=high;attack=spoofing"));
    sentPackets++;
    spoofedMessagesSent++;

    Simulator::Schedule(Seconds(attackTime2), &SendMessage,
                        maliciousSocket,
                        std::string("msgType=SAFETY_ALERT;sender=vehicle19;claimedId=" + std::to_string(spoofedIdentity) +
                                    ";speed=17;posX=108;posY=60;event=accident_warning;priority=high;attack=spoofing"));
    sentPackets++;
    spoofedMessagesSent++;

    Simulator::Schedule(Seconds(attackTime2), &PrintAttackStep,
                        std::string("third spoofing phase: vehicle19 sends fake collision warning"));

    Simulator::Schedule(Seconds(attackTime2), &SendMessage,
                        maliciousSocket,
                        std::string("msgType=SAFETY_ALERT;sender=vehicle19;claimedId=" + std::to_string(spoofedIdentity) +
                                    ";speed=19;posX=112;posY=64;event=collision_warning;priority=high;attack=spoofing"));
    sentPackets++;
    spoofedMessagesSent++;

    Simulator::Schedule(Seconds(attackTime3), &PrintAttackStep,
                        std::string("fourth spoofing phase: vehicle19 sends fake emergency brake alert"));

    Simulator::Schedule(Seconds(attackTime3), &SendMessage,
                        maliciousSocket,
                        std::string("msgType=SAFETY_ALERT;sender=vehicle19;claimedId=" + std::to_string(spoofedIdentity) +
                                    ";speed=21;posX=118;posY=67;event=emergency_brake;priority=high;attack=spoofing"));
    sentPackets++;
    spoofedMessagesSent++;

    Simulator::Schedule(Seconds(attackTime4), &PrintAttackStep,
                        std::string("fifth spoofing phase: vehicle19 sends fake congestion message"));

    Simulator::Schedule(Seconds(attackTime4), &SendMessage,
                        maliciousSocket,
                        std::string("msgType=TRAFFIC_STATUS;sender=vehicle19;claimedId=" + std::to_string(spoofedIdentity) +
                                    ";speed=8;posX=125;posY=70;density=heavy;status=congested;attack=spoofing"));
    sentPackets++;
    spoofedMessagesSent++;

    uint16_t rsuPort = 8000;

    Ptr<Socket> rsuRecvSocket = Socket::CreateSocket(rsus.Get(0), UdpSocketFactory::GetTypeId());
    InetSocketAddress rsuLocal = InetSocketAddress(Ipv4Address::GetAny(), rsuPort);
    rsuRecvSocket->Bind(rsuLocal);
    rsuRecvSocket->SetRecvCallback(MakeCallback(&ReceivePacket));

    Ptr<Socket> maliciousRsuSocket = Socket::CreateSocket(vehicles.Get(attackerVehicle), UdpSocketFactory::GetTypeId());
    InetSocketAddress remoteRsu = InetSocketAddress(interfaces.GetAddress(numVehicles), rsuPort);
    maliciousRsuSocket->Connect(remoteRsu);

    Simulator::Schedule(Seconds(attackTime3), &PrintAttackStep,
                        std::string("second spoofing phase: vehicle19 pretends to be vehicle" + std::to_string(spoofedIdentity)));

    Simulator::Schedule(Seconds(attackTime3), &PrintAttackStep,
                        std::string("a fake speed value is sent to mislead the network"));

    Simulator::Schedule(Seconds(attackTime3), &SendMessage,
                        maliciousRsuSocket,
                        std::string("msgType=SPEED_REPORT;sender=vehicle19;claimedId=" + std::to_string(spoofedIdentity) +
                                    ";speed=120;posX=110;posY=60;event=fake_speed_report;priority=medium;attack=spoofing"));
    sentPackets++;
    spoofedMessagesSent++;

    Simulator::Stop(Seconds(simTime));
    Simulator::Run();

    std::cout << "\n===== RESULTS =====\n";
    std::cout << "Sent Packets: " << sentPackets << std::endl;
    std::cout << "Received Packets: " << receivedPackets << std::endl;

    double pdr = 0.0;
    if (sentPackets > 0)
    {
        pdr = (double)receivedPackets / sentPackets * 100.0;
    }

    std::cout << "PDR: " << pdr << " %" << std::endl;
    std::cout << "Packet Loss: " << (sentPackets - receivedPackets) << std::endl;

    double throughput = (totalBytes * 8.0) / simTime / 1000.0;
    std::cout << "Throughput: " << throughput << " Kbps" << std::endl;

    std::cout << "\n===== MESSAGE PROFILE =====\n";
    std::cout << "Beacon Messages: " << beaconMessages << std::endl;
    std::cout << "Safety Messages: " << safetyMessages << std::endl;
    std::cout << "Traffic Messages: " << trafficMessages << std::endl;

    std::cout << "\n===== ATTACK FIELD ANALYSIS =====\n";
    std::cout << "Attack-Causing Field: claimedId" << std::endl;
    std::cout << "Normal Example: sender=vehicle0, claimedId=0" << std::endl;
    std::cout << "Spoofed Example: sender=vehicle19, claimedId=" << spoofedIdentity << std::endl;
    std::cout << "Attack Condition: sender != claimedId" << std::endl;

    double detectionAccuracy = 0.0;
    if (spoofedMessagesSent > 0)
    {
        detectionAccuracy = ((double)spoofedMessagesDetected / (double)spoofedMessagesSent) * 100.0;
    }

    double mitigationRate = 0.0;
    if (spoofedMessagesSent > 0)
    {
        mitigationRate = ((double)blockedSpoofedMessages / (double)spoofedMessagesSent) * 100.0;
    }

    std::cout << "\n===== SECURITY EVALUATION =====\n";
    std::cout << "Normal Messages: " << normalMessages << std::endl;
    std::cout << "Spoofed Messages Sent: " << spoofedMessagesSent << std::endl;
    std::cout << "Spoofed Messages Detected: " << spoofedMessagesDetected << std::endl;
    std::cout << "Detection Accuracy: " << detectionAccuracy << " %" << std::endl;
    std::cout << "Attacker Vehicle: " << attackerVehicle << std::endl;
    std::cout << "Spoofed Identity: " << spoofedIdentity << std::endl;
    std::cout << "Victim Vehicle: " << victimVehicle << std::endl;
    std::cout << "Detection Field: " << detectionField << std::endl;
    std::cout << "Blocked Spoofed Messages: " << blockedSpoofedMessages << std::endl;
    std::cout << "Mitigation Rate: " << mitigationRate << " %" << std::endl;

    Simulator::Destroy();
    visualFile.close();
    return 0;
}
