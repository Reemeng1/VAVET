#!/bin/bash

while true; do
    clear
    echo "========================================================"
    echo "                    VANET PROJECT MENU                  "
    echo "========================================================"
    echo "1) Show project information"
    echo "2) Run ns-3 simulation"
    echo "3) Run SUMO with colors"
    echo "4) Run full project"
    echo "5) Exit"
    echo "========================================================"
    echo
    read -p "Choose an option [1-5]: " choice

    case $choice in
        1)
            clear
            echo "Project: VANET spoofing attack simulation"
            echo "Tools  : ns-3 + SUMO + AODV + Python visualization"
            echo "Attack : Identity spoofing"
            echo "Detection field: sender vs claimedId"
            echo "Visualization : attacker / spoofed / victim / blocked / accident"
            echo
            read -p "Press Enter to return to menu..."
            ;;

        2)
            clear
            echo "========================================================"
            echo "                RUNNING NS-3 SIMULATION                 "
            echo "========================================================"
            cd ~/ns-3-dev || exit
            ./ns3 run scratch/vanet-spoofing
            echo
            read -p "Press Enter to return to menu..."
            ;;

        3)
            clear
            echo "========================================================"
            echo "                 RUNNING SUMO WITH COLORS               "
            echo "========================================================"
            cd ~/vanet || exit
            python3 color_attack.py
            echo
            read -p "Press Enter to return to menu..."
            ;;

        4)
            clear
            echo "========================================================"
            echo "                  RUNNING FULL PROJECT                  "
            echo "========================================================"
            echo
            echo "[1/2] Running ns-3 simulation..."
            cd ~/ns-3-dev || exit
            ./ns3 run scratch/vanet-spoofing

            echo
            echo "[2/2] Running SUMO with attack visualization..."
            cd ~/vanet || exit
            sleep 1
            python3 color_attack.py

            echo
            read -p "Press Enter to return to menu..."
            ;;

        5)
            echo "Exiting..."
            exit 0
            ;;

        *)
            echo "Invalid option."
            sleep 1
            ;;
    esac
done
